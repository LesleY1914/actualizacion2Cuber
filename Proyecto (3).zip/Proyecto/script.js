// Obtener el modal y el botón para abrirlo
var modal = document.getElementById("modalAgregarProducto");
var btnAgregarProducto = document.getElementById("btnAgregarProducto");

// Obtener el elemento span para cerrar el modal
var spanCerrar = document.querySelector(".close");

// Función para abrir el modal
function abrirModal() {
  modal.style.display = "block";
}

// Función para cerrar el modal
function cerrarModal() {
  modal.style.display = "none";
}

// Cerrar el modal cuando se hace clic en el span de cerrar
spanCerrar.onclick = function() {
  cerrarModal();
}

// Cerrar el modal cuando se hace clic fuera del modal
window.onclick = function(event) {
  if (event.target == modal) {
    cerrarModal();
  }
}

// Función para agregar un nuevo producto
// Función para agregar un nuevo producto
function agregarProducto() {
    var nombreProducto = document.getElementById("nombreProductoInput").value;
    var direccionProducto = document.getElementById("direcciónProductoInput").value;
    var nomDestinoProducto = document.getElementById("nomdestinoProductoInput").value;
  
    if (nombreProducto && direccionProducto && nomDestinoProducto) {
      var nuevoProducto = document.createElement("div");
      nuevoProducto.classList.add("producto");
      nuevoProducto.innerHTML = `
        <h2>${nombreProducto}</h2>
        <p>Dirección de destino: ${direccionProducto}</p>
        <p>Destinatario: ${nomDestinoProducto}</p>
        <button onclick="mostrarDetalles(this)">Más detalles</button>
        <div class="detalles" style="display: none;">
          <p>Estado: <span>Pendiente</span></p>
          <button onclick="cambiarEstado(this)">Cambiar Estado</button>
        </div>
      `;
      
      document.getElementById("productos").appendChild(nuevoProducto);
      
      cerrarModal();
    } else {
      alert("Por favor, complete todos los campos.");
    }
  }
  
  // Función para mostrar los detalles de un producto
  
  
  // Función para cambiar el estado de un producto
  function cambiarEstado(boton) {
    var producto = boton.parentNode.parentNode;
    var estado = producto.querySelector("span");
  
    switch (estado.innerText) {
      case "Pendiente":
        estado.innerText = "En camino";
        break;
      case "En camino":
        estado.innerText = "Entregado";
        break;
      case "Entregado":
        estado.innerText = "Pendiente";
        break;
      default:
        break;
    }
  }
  